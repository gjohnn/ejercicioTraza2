package org.example;

public enum TipoPromocion {
    HAPPY_HOUR, VERANO, INVIERNO
}
